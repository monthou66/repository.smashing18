source.txt gives the folder in smashingtemp/buildcustomskindialogs/output that 
            the 'Custom.smashing.' files here come from.
            
version.txt gives the version, to be used for updating.
version folder contains version for easy reading

xmlfolder.txt gives the name of the folder containing .xml files